﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Background;

namespace WRCBackgroundTasks
{
    public sealed class SessionConnectedTask : IBackgroundTask
    {
        public async void Run(IBackgroundTaskInstance taskInstance)
        {
            BackgroundTaskDeferral deferral = taskInstance.GetDeferral();
            var uri = new Uri("myuwp:");
            var res = await Windows.System.Launcher.LaunchUriAsync(uri);
            ToastHelper.PopToast("Connected Session Task", "Session Connected task is running", "OK");
            deferral.Complete();

        }
    }
}
